<div class="consent-div hide">
      <div id="consent-popup">
        <h5>Cookies Policy</h5>
       <hr>
        <p>
          Our website uses cookies. This helps us provide you with a good
          experience on our website. To see what cookies we use and what they
          do, and to opt-in on non-essential cookies click "change settings".
          For a detailed explanation, click on "<a href="#">Privacy Policy</a>"
          otherwise click "Accept Cookies" to enter.
        </p>
       <hr>
        <div class="btn-popup">
          <button id="setting">Change Settings</button>
          <button id="accept">Accept Cookies</button>
        </div>
      </div>
    </div>
    <div id="bground" class=""></div>