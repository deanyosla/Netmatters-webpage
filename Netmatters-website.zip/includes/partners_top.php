<a href="#" class="view-work"
          >View Our Work&nbsp;<i class="fa-solid fa-arrow-right"></i
        ></a>

        <div class="work-showcase top-partners">
          <a href="javascript: void(0)" class="greyscale">
            <img src="img/google-partner.jpg" alt="Google partner">
          </a>
          <a href="javascript: void(0)" class="greyscale">
            <img src="img/living_wage.png" alt="Living Wage"></a>
          <a href="javascript: void(0)" class="greyscale">
            <img src="img/norfolk_prohelp.png" alt="norfolk pro help">
          </a>
          <a href="javascript: void(0)" class="greyscale">
            <img class="center" src="img/investing-in-future-growth.jpg" alt="invest-in-future growth">
          </a>
          <a href="javascript: void(0)" class="greyscale">
            <img src="img/norfolk-carbon-charter.jpg" alt="norfolk carbon charter">
          </a>
          <a href="javascript: void(0)" class="greyscale">
            <img src="img/PPC_logo.jpg" alt="ppc logo">
          </a>
          <a href="javascript: void(0)" class="greyscale">
            <img class="center" src="img/princess-royal-training.jpg" alt="princess royal training award 2020">
          </a>
          <a href="javascript: void(0)" class="greyscale">
            <img src="img/future-50.jpg" alt="future 50 member">
          </a>
          <a href="javascript: void(0)" class="greyscale">
            <img src="img/qms.jpg" alt="qms certificate 9001">
          </a>
          <a href="javascript: void(0)" class="greyscale">
            <img src="img/iso_27001.jpg" alt="qms certificate 27001">
          </a>
          <a href="javascript: void(0)" class="greyscale">
            <img class="center" src="img/skills-of-tomorrow.jpg" alt="skills of tomorrow winner">
          </a>
        </div>