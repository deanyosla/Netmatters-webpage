    <div class="message">
      <button type="button"><i class="fa-solid fa-message"></i></button>
    </div>