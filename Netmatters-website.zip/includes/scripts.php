    <script src="js/jquery-3.7.1.min.js"></script>
    <script src="js/slick/slick.min.js"></script>
    <script src="js/slider.js"></script>
    <script src="js/main.js"></script>