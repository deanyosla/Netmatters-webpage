    <div class="consent">
      <button type="button" id="consent-btn">Manage Consent</button>
    </div> 